package chintaginjala.training;

public abstract class Instrument {
	public abstract void play();
}
